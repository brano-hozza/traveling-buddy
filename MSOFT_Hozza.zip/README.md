# TravellingBuddy
## MSOFT Projekt
### Branislav Hozza
Toto je kod k môjmu MSOFT projektu

## Spustenie projektu
### Minimálne požiadavky:
- Node.js
- Browser na spustenie
### Spustenie:
- V projekte spustiť príkazy:
  - `npm install`
  - `npm run dev`
- Otvoriť si link vypísaný v konzole (niečo na štýl http://localhost:5173)
